<?php

return [
    'day'       => 'dzień',
    'days'      => 'dni',
    'hour'      => 'godzina',
    'hours'     => 'godziny',
    'hours2'    => 'godzin',
    'minute'    => 'minuta',
    'minutes'   => 'minuty',
    'minutes2'  => 'minut',
    'second'    => 'sekunda',
    'seconds'   => 'sekundy',
    'seconds2'  => 'sekund',

    'vue'       => [
        'global' => [
            // Nav
            'server'        => 'Serwer',
            'top'           => 'Ranking',
            'info'          => 'Informacje',
            'client'        => 'Klient',

            // Others
            'nick'          => 'Nick',
            'status'        => 'Status',
            'place'         => 'Miejsce',
            'online'        => 'Aktywny',
            'offline'       => 'Nieaktywny',
            'channel'       => 'Kanał',
            'dbid'          => 'Database id',
            'uid'           => 'Unikalny identyfikator',
            'loading'       => 'Ładowanie . . .',
            'connect'       => 'Połącz się!',
            'search'        => 'Szukaj',
            'isActive'      => 'Jest aktywny od: ',
            'lastOnline'    => 'Ostatnio aktywny: ',
            'clickToUrl'    => 'Kliknij, aby przejść do profilu',
            'groups'        => 'Grupy',
        ],
        'socketIo'  => [
            'connectError'      => 'Błąd podczas połączenia z serwerem! Niektóre funkcje mogą być ograniczone.' ,
            'reconnectSuccess'  => 'Połaczono z serwerem pomyślnie.',

        ],
        // Footer
        'footer' => [
            'info'      => 'Informacje',
            'followUs'  => 'Obserwuj nas!',
            'copyright' => 'Wszystkie prawa zastrzeżone',
        ],
        // FooterServerInfo
        'footerServerInfo' => [
            'tooltip'   => 'Kliknij, aby odświeżyć!',
            'server'    => 'Serwer',
            'name'      => 'Serwer',
            'online'    => 'Online',
            'channels'  => 'Kanałów',
            'ping'      => 'Ping',
            'error'     => 'Błąd podczas pobierania danych (Stopka)',
        ],
        // Login
        'login' => [
            'loading'         => 'Ładowanie',
            'sendingToken'    => 'Wysyłanie tokenu',
            'checkingToken'   => 'Sprawdzanie tokenu',
            'logout'          => 'Wylogowano pomyślnie',
            'logoutButton'    => 'Wyloguj',
            'notOnServer'     => 'Nie znaleziono Cię na serwerze',
            'selectAccount'   => 'Wybierz konto',
            'haveToChoose'    => 'Musisz wybrać jakieś konto',
            'typeToken'       => 'Podaj token',
            'haveToTypeToken' => 'Musisz podać token!',
            'loginSuccess'    => 'Zalogowano pomyślnie.',
            'invalidToken'    => 'Niepoprawny token!',
            'notOnServerMore' => 'Podany użytkownik nie znajduje się już na serwerze.',
        ],
        // Home
        'home' => [
            'name'      => 'Strona główna',
            'admins'    => [
                'title' => 'Profesjonalna administracja',
                'desc'  => 'Na naszym serwerze znajdują się tylko doświadczone osoby.'
            ],
            'view'      => [
                'title' => 'Wygląd',
                'desc'  => 'Nasz serwer posiada autorski układ kanałów, który każdemu przypadnie do gustu.'
            ],
            'automation' => [
                'title' => 'Automatyzacja',
                'desc'  => 'Posiadamy wysokiej jakości bota, który odpowiada za automatyzacją naszego serwera.'
            ],
            'counter'   => [
                'clients'       => 'Użytkowników',
                'spentHours'    => 'Spędzonych godzin',
                'connections'   => 'Połączeń',
            ]
        ],
        // Regulations
        'regulations' => [
            'error'     => 'Błąd podczas pobierania danych (Regulamin)',
            'name'      => 'Regulamin',
            'titleDesc' => 'Przestrzegaj go!',
        ],
        // Faq
        'faq' => [
            'error'     => 'Błąd podczas pobierania danych (FAQ)',
            'name'      => 'FAQ',
            'titleDesc' => 'Szybkie pytania i odpowiedzi',
        ],
        // Contact
        'contact' => [
            'name'      => 'Kontakt',
            'titleDesc' => 'Napisz do nas',
            'header'    => 'Napisz do nas!',
            'nick'      => 'Nick',
            'email'     => 'Email',
            'subject'   => 'Temat',
            'message'   => 'Wiadomość',
            'sentBtn'   => 'Wyślij wiadomość',
            'send'      => 'Wiadomość została wysłana!',
            'error'     => 'Błąd przy wysyłaniu wiadomości. Spróbuj ponownie później! Być może musisz trochę odczekać.',
            'notSent'   => 'Wiadomość nie została wysłana!',
        ],
        // Groups
        'groups' => [
            'name'      => 'Grupy',
            'titleDesc' => 'Zarządzaj swoimi grupami',
            'authError' => 'Najpierw się zaloguj!',
            'error'     => 'Bład podczas pobierania danych (Lista grup)'
        ],
        // top/Connections
        'connections' => [
            'name'      => 'TOP ilości połączeń',
            'error'     => 'Błąd podczas pobierania danych (TOP ilości połączeń)',
            'field'     => 'Liczba połączeń',
        ],
        // top/IdleTimeRecord
        'idleTimeRecord' => [
            'name'      => 'Najdłuższy czas AFK',
            'error'     => 'Błąd podczas pobierania danych (Najdłuższy czas AFK)',
            'field'     => 'Najdłuższy okres AFK',
        ],
        // top/IdleTimeSpent
        'idleTimeSpent' => [
            'name'      => 'TOP spędzonego czasu AFK',
            'error'     => 'Błąd podczas pobierania danych (TOP spędzonego czasu AFK)',
            'field'     => 'Spędzony czas AFK',
        ],
        // top/TimeRecord
        'timeRecord' => [
            'name'      => 'Najdłuższe połączenie',
            'error'     => 'Błąd podczas pobierania danych (Najdłuższe połączenie)',
            'field'     => 'Najdłuższe połączenie',
        ],
        // top/TimeSpent
        'timeSpent'  => [
            'name'      => 'TOP spędzonego czasu',
            'error'     => 'Błąd podczas pobierania danych (TOP spędzonego czasu)',
            'field'     => 'Spędzony czas',
        ],
        // ClientsOnline
        'clientsOnline' => [
            'name'      => 'Klienci online',
            'titleDesc' => 'Dostępni użytkownicy na naszym serwerze',
            'none'      => 'Brak użytkowników online',
            'error'     => 'Błąd podczas pobierania danych (Klienci online)'
        ],
        // Admins
        'admins' => [
            'name'      => 'Administratorzy',
            'titleDesc' => 'Czuwający nad porządkiem na naszym serwerze',
            'error'     => 'Błąd podczas pobierania danych (Administratorzy)',
        ],
        // Client
        'client' => [
            'name'                  => 'Dane użytkownika',
            'info'                  => 'Informacje',
            'moreInfo'              => 'Szczegóły',
            'lastNicks'             => 'Ostatnie nicki',
            'connections'           => 'Ilość połączeń',
            'connectedTimeRecord'   => 'Najdłuższe połączenie',
            'connectedTimeSpent'    => 'Spędzony czas',
            'idleTimeRecord'        => 'Najdłuższy czas AFK',
            'idleTimeSpent'         => 'Spędzony czas AFK',
            'clickToTop'            => 'Kliknij, aby zobaczyć topkę',
            'error'                 => 'Błąd podczas pobierania danych (Klient)',
        ],
        // Server
        'server' => [
            'name'      => 'Informacje serwera',
            'titleDesc' => 'Zobacz informacje o naszym serwerze',
            'error'     => 'Błąd podczas pobierania danych (Serwer)',
            'moreInfo'  => [
                'title'         => 'Więcej informacji',
                'serverName'    => 'Nazwa serwera',
                'platform'      => 'Platforma',
                'version'       => 'Wersja',
                'port'          => 'Port serwera',
                'uptime'        => 'Serwer działa przez',
                'ping'          => 'Ping',
                'packetLoss'    => 'Packet loss',
                'online'        => 'Online',
                'channels'      => 'Kanałów',

            ]
        ],
        // Search
        'search' => [
            'name'          => 'Wyszukiwanie',
            'titleDesc'     => 'Znajdź użytkownika',
            'searching'     => 'Wyszukiwanie: ',
            'none'          => 'Brak wyników, spróbuj użyć innej frazy',
            'errorPhrase'   => 'Wprowadź co najmniej 3 znaki!',
            'results'       => 'Wyników: ',
            'error'         => 'Błąd podczas pobierania danych (Wyszukiwanie)',
        ],
        // Error404
        'error404' => [
            'name'      => 'Error404',
            'titleDesc' => 'Strona nie została znaleziona!',
            'info'      => 'Kurczę, strona której szukasz nie została znaleziona lub nie istnieje!',
            'infoSpan'  => 'Skorzystaj z poniższych linków, aby powrócić do aplikacji :D'
        ],
    ],
    'bot' => [
        'connected'     => [
            'downloadLang'  => '> [DATE] - Pobrano tłumaczenia ze strony',
            'ts3init'       => '> [DATE] - Łączenie z serwerem TeamSpeak3',
            'ts3'           => '> [DATE] - Połączono z serwerem TeamSpeak3',
            'http' 			=> '> [DATE] - Wystartowano serwer bez SSL',
            'https' 		=> '> [DATE] - Wystartowano serwer z certyfikatem SSL',
        ],
        'addGroup' 		=> [
            'logInfoSuccess'	 => '> [DATE] - SUKCES | Zmiana grup | Dbid: [DBID] | IP: [IP]',
            'logInfoError'	 	 => '> [DATE] - ERROR | Zmiana grup | INFO: [INFO] | Dbid: [DBID] | IP: [IP]',
            'limitErr' 			 => 'Za dużo grup w sekcji [SECTION]. Limit: [LIMIT]',
            'wrongGroup' 		 => 'Nie możesz nadać tej grupy. Sgid: [SGID]',
            'cannotAccessServer' => 'Nie można pobrać danych z serwera',
            'authError'		 	 => 'Błąd uwierzytelnienia. Wylogowywanie',
			'clientMsgSuccess'   => '[color=#FF9100]➜[/color] [color=#E88D2E]Grupy zmienione [/color][b] [color=lightgreen] pomyślnie [/b]',
			'clientMsgError'     => '[color=#FF9100]➜[/color] [color=#E80C22][b]Wystąpił błąd podczas zmiany grup',
        ],
        'ts3Error' 		=> '> Błąd podczas łączenia do serwera TeamSpeak3',
        'checkToken'	=> [
            'logInfoSuccess'	=> '> [DATE] - SUKCES | Sprawdzanie tokenu: [TOKEN] | Dbid: [DBID] | IP: [IP]',
            'logInfoError'		=> '> [DATE] - ERROR | Sprawdzanie tokenu: [TOKEN] | Dbid: [DBID] | IP: [IP]',
            'clientMsgSuccess'	=> '[color=#FF9100]➜[/color] [color=#E88D2E]Zostałeś zalogowany [/color][b] [color=lightgreen] pomyślnie [/b]',
            'clientMsgError'	=> '[color=#FF9100]➜[/color] [color=#E88D2E]Logowanie[/color][b] [color=#E80C22] nie powiodło się [/b] ',
        ],
        'sendToken'		=> [
            'logInfoAlreadySent' => '> [DATE] - SUKCES | Token już wysłany: [TOKEN] | Dbid: [DBID] | IP: [IP]',
            'logInfoSuccess'	 => '> [DATE] - SUKCES | Wysyłanie tokenu: [TOKEN] | Dbid: [DBID] | IP: [IP]',
            'logInfoError'		 => '> [DATE] - ERROR | Wysyłanie tokenu: [TOKEN] | Dbid: [DBID] | IP: [IP]',
            'clientMsg'			 => '[color=#FF9100]➜[/color] [color=#E88D2E] Twój token uwierzytelniający: [/color] [b][color=#FF7D33] [i][TOKEN][/i] [/color][/b]   [color=#E88D2E] Ważny przez [TIME] sekund [/color]',
        ],
        'getClients'	=> [
            'logInfo' => '> [DATE] - Pobieranie użytkowników: [CLIENTS] | IP: [IP]',
        ],
		'logout'		=> [
			'logInfo' 	=> '> [DATE] - Wylogowywanie | Dbid: [DBID] | IP: [IP]',
			'clientMsg'	=> '[color=#FF9100]➜[/color] [color=#E88D2E]Wylogowano [/color][b] [color=lightgreen] pomyślnie [/b]',
		]

    ],
];
