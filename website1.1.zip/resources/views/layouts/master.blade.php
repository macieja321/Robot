<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
    <!-- Meta tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <!-- Author Meta -->
    <meta name="author" content="Tymoteusz `RazorMeister` Bartnik">
    <!-- Meta Description -->
    <meta name="description" content="{{ config('config.main.siteDescription') }}">
    <!-- Meta Keyword -->
    <meta name="keywords" content="{{ config('config.main.keywords') }}">
    <!-- Meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>{{ config('config.main.siteName') }}</title>
    <!-- Csrf token -->
    <meta name="csrf-token" content="{{ csrf_token()  }}">

    <!-- Stylesheets
    ============================================= -->
    <link rel="stylesheet" href="{{ asset('css/sweetAlertDark.min.css') }}" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Raleway:300,400,500,600,700|Crete+Round:400i" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{ asset('css/font-icons.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('css/all.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}" type="text/css">
    <link rel="stylesheet" href="{{ asset('fontawesome/css/all.min.css') }}" type="text/css">
    <style>
        /* ----------------------------------------------------------------
            Colors

            Replace the HEX Code with your Desired Color HEX
        -----------------------------------------------------------------*/

        ::selection { background: {!! config('config.main.themeColor') !!}; }
        ::-moz-selection { background: {!! config('config.main.themeColor') !!}; }
        ::-webkit-selection { background: {!! config('config.main.themeColor') !!}; }
        a,
        h1 > span:not(.nocolor):not(.badge),
        h2 > span:not(.nocolor):not(.badge),
        h3 > span:not(.nocolor):not(.badge),
        h4 > span:not(.nocolor):not(.badge),
        h5 > span:not(.nocolor):not(.badge),
        h6 > span:not(.nocolor):not(.badge),
        .header-extras li .he-text span,
        #primary-menu ul li:hover > a,
        #primary-menu ul li.current > a,
        #primary-menu div ul li:hover > a,
        #primary-menu div ul li.current > a,
        #primary-menu ul ul li:hover > a,
        #primary-menu ul li .mega-menu-content.style-2 ul.mega-menu-column > li.mega-menu-title > a:hover,
        #top-cart > a:hover,
        .top-cart-action span.top-checkout-price,
        .breadcrumb a:hover,
        .portfolio-filter li a:hover,
        .portfolio-desc h3 a:hover,
        .portfolio-overlay a:hover,
        #portfolio-navigation a:hover,
        .entry-title h2 a:hover,
        .entry-meta li a:hover,
        .post-timeline .entry:hover .entry-timeline,
        .post-timeline .entry:hover .timeline-divider,
        .ipost .entry-title h3 a:hover,
        .ipost .entry-title h4 a:hover,
        .spost .entry-title h4 a:hover,
        .mpost .entry-title h4 a:hover,
        .comment-content .comment-author a:hover,
        .product-title h3 a:hover,
        .single-product .product-title h2 a:hover,
        .product-price ins,
        .single-product .product-price,
        .feature-box.fbox-border .fbox-icon i,
        .feature-box.fbox-border .fbox-icon img,
        .feature-box.fbox-plain .fbox-icon i,
        .feature-box.fbox-plain .fbox-icon img,
        .process-steps li.active h5,
        .process-steps li.ui-tabs-active h5,
        .team-title span,
        .pricing-box.best-price .pricing-price,
        .btn-link,
        .dark .post-timeline .entry:hover .entry-timeline,
        .dark .post-timeline .entry:hover .timeline-divider,
        .clear-rating-active:hover { color: {!! config('config.main.themeColor') !!}; }
        .color,
        .top-cart-item-desc a:hover,
        .portfolio-filter.style-3 li.activeFilter a,
        .faqlist li a:hover,
        .tagcloud a:hover,
        .dark .top-cart-item-desc a:hover,
        .iconlist-color li i,
        .dark.overlay-menu #header-wrap:not(.not-dark) #primary-menu > ul > li:hover > a,
        .dark.overlay-menu #header-wrap:not(.not-dark) #primary-menu > ul > li.current > a,
        .overlay-menu #primary-menu.dark > ul > li:hover > a,
        .overlay-menu #primary-menu.dark > ul > li.current > a,
        .nav-tree li:hover > a,
        .nav-tree li.current > a,
        .nav-tree li.active > a { color: {!! config('config.main.themeColor') !!} !important; }
        #primary-menu.style-3 > ul > li.current > a,
        #primary-menu.sub-title > ul > li:hover > a,
        #primary-menu.sub-title > ul > li.current > a,
        #primary-menu.sub-title > div > ul > li:hover > a,
        #primary-menu.sub-title > div > ul > li.current > a,
        #top-cart > a > span,
        #page-menu-wrap,
        #page-menu ul ul,
        #page-menu.dots-menu nav li.current a,
        #page-menu.dots-menu nav li div,
        .portfolio-filter li.activeFilter a,
        .portfolio-filter.style-4 li.activeFilter a:after,
        .portfolio-shuffle:hover,
        .entry-link:hover,
        .sale-flash,
        .button:not(.button-white):not(.button-dark):not(.button-border):not(.button-black):not(.button-red):not(.button-teal):not(.button-yellow):not(.button-green):not(.button-brown):not(.button-aqua):not(.button-purple):not(.button-leaf):not(.button-pink):not(.button-blue):not(.button-dirtygreen):not(.button-amber):not(.button-lime):not(:hover),
        .button.button-dark:hover,
        .promo.promo-flat,
        .feature-box .fbox-icon i,
        .feature-box .fbox-icon img,
        .fbox-effect.fbox-dark .fbox-icon i:hover,
        .fbox-effect.fbox-dark:hover .fbox-icon i,
        .fbox-border.fbox-effect.fbox-dark .fbox-icon i:after,
        .i-rounded:hover,
        .i-circled:hover,
        ul.tab-nav.tab-nav2 li.ui-state-active a,
        .testimonial .flex-control-nav li a,
        .skills li .progress,
        .owl-carousel .owl-dots .owl-dot,
        #gotoTop:hover,
        .dark .button-dark:hover,
        .dark .fbox-effect.fbox-dark .fbox-icon i:hover,
        .dark .fbox-effect.fbox-dark:hover .fbox-icon i,
        .dark .fbox-border.fbox-effect.fbox-dark .fbox-icon i:after,
        .dark .i-rounded:hover,
        .dark .i-circled:hover,
        .dark ul.tab-nav.tab-nav2 li.ui-state-active a,
        .dark .tagcloud a:hover,
        .ei-slider-thumbs li.ei-slider-element,
        .nav-pills .nav-link.active,
        .nav-pills .nav-link.active:hover,
        .nav-pills .nav-link.active:focus,
        .nav-pills .show > .nav-link,
        .checkbox-style:checked + .checkbox-style-1-label:before,
        .checkbox-style:checked + .checkbox-style-2-label:before,
        .checkbox-style:checked + .checkbox-style-3-label:before,
        .radio-style:checked + .radio-style-3-label:before,
        .irs-bar,
        .irs-from,
        .irs-to,
        .irs-single,
        input.switch-toggle-flat:checked + label,
        input.switch-toggle-flat:checked + label:after,
        input.switch-toggle-round:checked + label:before,
        .bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-themecolor,
        .bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-themecolor,
        .entry:after { background-color: {!! config('config.main.themeColor') !!}; }
        .bgcolor,
        .button.button-3d:not(.button-white):not(.button-dark):not(.button-border):not(.button-black):not(.button-red):not(.button-teal):not(.button-yellow):not(.button-green):not(.button-brown):not(.button-aqua):not(.button-purple):not(.button-leaf):not(.button-pink):not(.button-blue):not(.button-dirtygreen):not(.button-amber):not(.button-lime):hover,
        .process-steps li.active a,
        .process-steps li.ui-tabs-active a,
        .sidenav > .ui-tabs-active > a,
        .sidenav > .ui-tabs-active > a:hover,
        .owl-carousel .owl-nav [class*=owl-]:hover,
        .page-item.active .page-link,
        .page-link:hover,
        .page-link:focus { background-color: {!! config('config.main.themeColor') !!} !important; }
        #primary-menu.style-4 > ul > li:hover > a,
        #primary-menu.style-4 > ul > li.current > a,
        .top-cart-item-image:hover,
        .portfolio-filter.style-3 li.activeFilter a,
        .post-timeline .entry:hover .entry-timeline,
        .post-timeline .entry:hover .timeline-divider,
        .cart-product-thumbnail img:hover,
        .feature-box.fbox-outline .fbox-icon,
        .feature-box.fbox-border .fbox-icon,
        .dark .top-cart-item-image:hover,
        .dark .post-timeline .entry:hover .entry-timeline,
        .dark .post-timeline .entry:hover .timeline-divider,
        .dark .cart-product-thumbnail img:hover,
        .heading-block.border-color:after { border-color: {!! config('config.main.themeColor') !!}; }
        .top-links ul ul,
        .top-links ul div.top-link-section,
        #primary-menu ul ul:not(.mega-menu-column),
        #primary-menu ul li .mega-menu-content,
        #primary-menu.style-6 > ul > li > a:after,
        #primary-menu.style-6 > ul > li.current > a:after,
        #top-cart .top-cart-content,
        .fancy-title.title-border-color:before,
        .dark #primary-menu:not(.not-dark) ul ul,
        .dark #primary-menu:not(.not-dark) ul li .mega-menu-content,
        #primary-menu.dark ul ul,
        #primary-menu.dark ul li .mega-menu-content,
        .dark #primary-menu:not(.not-dark) ul li .mega-menu-content.style-2,
        #primary-menu.dark ul li .mega-menu-content.style-2,
        .dark #top-cart .top-cart-content,
        .tabs.tabs-tb ul.tab-nav li.ui-tabs-active a,
        .irs-from:after,
        .irs-single:after,
        .irs-to:after { border-top-color: {!! config('config.main.themeColor') !!}; }
        #page-menu.dots-menu nav li div:after,
        .title-block { border-left-color: {!! config('config.main.themeColor') !!}; }
        .title-block-right { border-right-color: {!! config('config.main.themeColor') !!}; }
        .fancy-title.title-bottom-border h1,
        .fancy-title.title-bottom-border h2,
        .fancy-title.title-bottom-border h3,
        .fancy-title.title-bottom-border h4,
        .fancy-title.title-bottom-border h5,
        .fancy-title.title-bottom-border h6,
        .more-link,
        .tabs.tabs-bb ul.tab-nav li.ui-tabs-active a { border-bottom-color: {!! config('config.main.themeColor') !!}; }
        .border-color,
        .process-steps li.active a,
        .process-steps li.ui-tabs-active a,
        .tagcloud a:hover,
        .page-item.active .page-link,
        .page-link:hover,
        .page-link:focus { border-color: {!! config('config.main.themeColor') !!} !important; }
        .fbox-effect.fbox-dark .fbox-icon i:after,
        .dark .fbox-effect.fbox-dark .fbox-icon i:after { box-shadow: 0 0 0 2px {!! config('config.main.themeColor') !!}; }
        .fbox-border.fbox-effect.fbox-dark .fbox-icon i:hover,
        .fbox-border.fbox-effect.fbox-dark:hover .fbox-icon i,
        .dark .fbox-border.fbox-effect.fbox-dark .fbox-icon i:hover,
        .dark .fbox-border.fbox-effect.fbox-dark:hover .fbox-icon i { box-shadow: 0 0 0 1px {!! config('config.main.themeColor') !!}; }
        @media only screen and (max-width: 991px) {
            body:not(.dark) #header:not(.dark) #header-wrap:not(.dark) #primary-menu > ul > li:hover a,
            body:not(.dark) #header:not(.dark) #header-wrap:not(.dark) #primary-menu > ul > li.current a,
            body:not(.dark) #header:not(.dark) #header-wrap:not(.dark) #primary-menu > div > ul > li:hover a,
            body:not(.dark) #header:not(.dark) #header-wrap:not(.dark) #primary-menu > div > ul > li.current a,
            #primary-menu ul ul li:hover > a,
            #primary-menu ul li .mega-menu-content.style-2 > ul > li.mega-menu-title:hover > a,
            #primary-menu ul li .mega-menu-content.style-2 > ul > li.mega-menu-title > a:hover { color: {!! config('config.main.themeColor') !!} !important; }
            #page-menu nav { background-color: {!! config('config.main.themeColor') !!}; }  }
        @media only screen and (max-width: 767px) {  .portfolio-filter li a:hover { color: {!! config('config.main.themeColor') !!}; }  }
        #primary-menu ul li > a.router-link-active {color: {!! config('config.main.themeColor') !!};}
        .text-accent {color: {!! config('config.main.themeColor') !!};}
    </style>
    <!-- @if(config('config.main.darkTheme')) <link rel="stylesheet" href="{{ asset('css/sweetAlertDark.min.css') }}" type="text/css"> @endif -->
</head>

<body class="stretched no-transition @if(config('config.main.darkTheme')) dark @endif">

<!-- Document Wrapper
============================================= -->
<div id="wrapper" class="clearfix">

    <!-- Header
    ============================================= -->
    <transition name="fade" appear>
        <header id="header" class="transparent-header full-header" data-sticky-class="" style="display: none">
            <div id="header-wrap">
                <div class="container clearfix">
                    <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

                    <!-- Logo
                    ============================================= -->
                    <div id="logo">
                        <router-link :to="{name: 'home'}" class="standard-logo-logo" data-dark-logo="{{ asset('images/logo-robot.jpg') }}"><img src="{{ asset('images/logo-robot.jpg') }}" alt="Canvas Logo"></router-link>
                    </div><!-- #logo end -->

                    <!-- Primary Navigation
                    ============================================= -->
                    <nav id="primary-menu" class="style-5">
                        <ul>
                            <li><router-link :to="{name: 'home'}"><div><i class="fa fa-home"></i> {{ trans('lang.vue.home.name') }}</div></router-link></li>
                            <li><router-link :to="{name: 'server'}"><div><i class="fa fa-server"></i> {{ trans('lang.vue.global.server') }}</div></router-link></li>
                            <li class="parent-link">
                                <a :class="{'router-link-active': isRoute(['top.timeSpent','top.timeRecord','top.connections','top.idleTimeSpent','top.idleTimeRecord'])}">
                                    <div><i class="fa fa-trophy"></i> {{ trans('lang.vue.global.top') }}</div>
                                </a>
                                <ul>
                                    <li><router-link :to="{name: 'top.timeSpent'}"><div><i class="fa fa-star"></i> {{ trans('lang.vue.timeSpent.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'top.timeRecord'}"><div><i class="fa fa-star"></i> {{ trans('lang.vue.timeRecord.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'top.connections'}"><div><i class="fa fa-star"></i> {{ trans('lang.vue.connections.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'top.idleTimeSpent'}"><div><i class="fa fa-star"></i> {{ trans('lang.vue.idleTimeSpent.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'top.idleTimeRecord'}"><div><i class="fa fa-star"></i> {{ trans('lang.vue.idleTimeRecord.name') }}</div></router-link></li>
                                </ul>
                            </li>
                            <li class="parent-link">
                                <a :class="{'router-link-active': isRoute(['regulations','faq','clientsOnline','admins'])}">
                                    <div><i class="fa fa-info"></i> {{ trans('lang.vue.global.info') }}</div>
                                </a>
                                <ul>
                                    <li><router-link :to="{name: 'admins'}"><div><i class="fa fa-user-secret"></i> {{ trans('lang.vue.admins.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'clientsOnline'}"><div><i class="fa fa-users"></i> {{ trans('lang.vue.clientsOnline.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'regulations'}"><div><i class="fa fa-gavel"></i> {{ trans('lang.vue.regulations.name') }}</div></router-link></li>
                                    <li><router-link :to="{name: 'faq'}"><div><i class="fa fa-question"></i> {{ trans('lang.vue.faq.name') }}</div></router-link></li>
                                </ul>
                            </li>
                            <li><router-link :to="{name: 'groups'}"><div><i class="fa fa-plus-circle"></i> {{ trans('lang.vue.groups.name') }}</div></router-link></li>
                            <li><router-link :to="{name: 'contact'}"><div><i class="fa fa-envelope"></i> {{ trans('lang.vue.contact.name') }}</div></router-link></li>
                        </ul>

                        <!-- Top Search
                        ============================================= -->
                        <search></search>
                        <!-- #top-search end -->

                        <!-- Login button
                        ============================================= -->
                        <login></login>
                        <!-- #login-button end -->
                    </nav><!-- #primary-menu end -->
                </div>
            </div>
        </header>
    </transition><!-- #header end -->

    <!-- Slider
    ============================================= -->
    <slider></slider>
    <!-- Slider end -->

    <!-- Router view
    ============================================= -->
    <router-view></router-view>
    <!-- Router view end -->

    <!-- Footer
    ============================================= -->
    <transition name="fadeUp" appear>
        <footer id="footer" class="dark" style="display: none">
            <div class="container">
                <!-- Footer Widgets
                ============================================= -->
                <div class="footer-widgets-wrap clearfix">
                    <div class="col_one_third">
                        <div class="widget widget_links clearfix">
                            <h4><i class="fa fa-info"></i> {{ trans('lang.vue.footer.info') }}</h4>
                            <p> {!! config('config.footer.info') !!}</p>
                            <ul>
                                <li><router-link :to="{ name: 'contact' }">{{ trans('lang.vue.contact.name') }}</router-link></li>
                                <li><router-link :to="{ name: 'regulations' }">{{ trans('lang.vue.regulations.name') }}</router-link></li>
                                <li><router-link :to="{ name: 'faq' }">{{ trans('lang.vue.faq.name') }}</router-link></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col_one_third">
                        <footer-server-info></footer-server-info>
                    </div>

                    <div class="col_one_third col_last">
                        <div class="widget clearfix">
                            <h4><i class="fa fa-eye"></i> {{ trans('lang.vue.footer.followUs') }}</h4>
                            <div id="fb-root"></div>
                            <div class="fb-page" data-href="{!! config('config.facebook.link') !!}" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                <div class="fb-xfbml-parse-ignore">
                                    <blockquote cite="{!! config('config.facebook.link') !!}"><a href="{!! config('config.facebook.link') !!}" >{{ config('config.facebook.name') }}</a></blockquote>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- .footer-widgets-wrap end -->
            </div>

            <!-- Copyrights
            ============================================= -->
                <div id="copyrights">
                    <div class="container clearfix">
                        <div class="col_one_third">
                            Copyright &copy; @if(date('Y') > 2019) 2019 - {{ date('Y') }} @else 2019 @endif {{ trans('lang.vue.footer.copyright') }}
                        </div>
                        <div class="col_one_third text-center clearfix">
                            Coding <span class="text-danger ml-2 mr-2"><i class="fa fa-heart"></i></span> <a href="http://razormeister.pl" target="_blank"> RazorMeister </a>
                        </div>
                        <div class="col_one_third col_last tright">
                            <div class="fright clearfix">
                                <a href="{!! config('config.facebook.link') !!}" target="_blank" class="social-icon si-small si-borderless si-facebook">
                                    <i class="icon-facebook"></i>
                                    <i class="icon-facebook"></i>
                                </a>
                            </div>

                        </div>
                    </div>
                </div><!-- #copyrights end -->

        </footer>
    </transition><!-- #footer end -->

</div><!-- #wrapper end -->

<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>

<!-- Setting global vars for vue
============================================= -->
<script>
    const trans = {!! json_encode(Illuminate\Support\Facades\Lang::get('lang.vue')) !!};
    const cfg = {!! json_encode($vueCfg) !!}
</script>

<!-- External JavaScripts
============================================= -->
<script src="{{ asset('js/app.js') }}"></script>
<script src="{{ asset('js/plugins.js') }}"></script>
<script src="{{ asset('js/functions.js') }}"></script>
<script src="{{ asset('js/custom.js') }}"></script>

<!-- Facebook Script
============================================= -->
<script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/pl_PL/sdk.js#xfbml=1&version=v2.4&appId=244261725605652";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>

</body>
</html>