@component('mail::message')
    # Nowa wiadomość od: {{ $nick }} #

    ## Tytuł: {{ $subject }} ##

    {{ $message }}

    {{ config('app.name') }}
@endcomponent