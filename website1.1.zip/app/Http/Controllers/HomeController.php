<?php

namespace App\Http\Controllers;

use App\Helpers\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;

class HomeController extends Controller
{
    protected $helper;

    /**
     * HomeController constructor.
     *
     * @param Helper $helper
     */
    public function __construct(Helper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Return master layout to vue app.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        return view('layouts.master')->with(['vueCfg' => $this->helper->getVueCfg()]);
    }

    /**
     * Clear website cache.
     *
     * @return string
     */
    public function clearCache()
    {
        Artisan::call('cache:clear');
        Artisan::call('route:clear');
        Artisan::call('config:clear');
        Artisan::call('view:clear');
        Artisan::call('optimize');

        $vueCfg = $this->helper->getVueCfg();

        $toReturn = "<b>CACHE CLEARED!</b><br>(ENV) APP_URL = ".env('APP_URL')."<br>(ENV) SSL = ".env('SSL')."<br>(ENV) CLOUDFLARE_SSL = ".env("CLOUDFLARE_SSL")."<br>";
        $toReturn .= "(Config) Subfolder = ".$vueCfg['subfolder']."<br>(Config) Socket IO = ".$vueCfg['socketIo']['host'];

        return $toReturn;
    }
}
