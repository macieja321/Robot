<?php

namespace App\Http\Controllers\API;

use App\Client;
use App\Helpers\Helper;
use App\ServerGroup;
use App\Http\Controllers\Controller;

class GroupsController extends Controller
{
    protected $helper;

    /**
     * GroupController constructor.
     *
     * @param Helper $helper
     */
    public function __construct(Helper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Get client groups.
     *
     * @param $dbid
     *
     * @return array
     */
    public function index($dbid)
    {
        $toReturn = [];
        $client = Client::where('clientDbid', $dbid)->first();

        if ($client) {
            $clientGroups = explode(',', $client->serverGroups);

            foreach (config('config.manageGroups') as $section => $info) {
                $toReturn[$section]['limit'] = $info['limit'];
                $toReturn[$section]['groups'] = [];
            }

            foreach (ServerGroup::all() as $serverGroup)
                foreach (config('config.manageGroups') as $section => $info)
                    if (in_array($serverGroup->sgid, $info['groups'])) {
                        $toReturn[$section]['groups'][] = ['name' => $serverGroup->name, 'sgid' => $serverGroup->sgid];

                        if (in_array($serverGroup->sgid, $clientGroups))
                            $toReturn[$section]['value'][] = ['name' => $serverGroup->name, 'sgid' => $serverGroup->sgid];
                    }

            return $toReturn;
        } else
            abort(404);
    }
}
