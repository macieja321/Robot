<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Lang;

class BotLangController extends Controller
{
    /**
     * Get language for bot.
     *
     * @return array|string|null
     */
    public function index()
    {
        return Lang::get('lang.bot');
    }
}
