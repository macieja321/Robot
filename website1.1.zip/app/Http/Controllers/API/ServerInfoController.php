<?php

namespace App\Http\Controllers\API;

use App\Helpers\Helper;
use App\ServerInfo;
use App\Http\Controllers\Controller;

class ServerInfoController extends Controller
{
    protected $helper;

    /**
     * ServerInfoController constructor.
     *
     * @param Helper $helper
     */
    public function __construct(Helper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Return server info for FooterServerInfo component.
     *
     * @return array
     */
    public function home()
    {
        $returnKeys = [
            'virtualserver_maxclients',
            'virtualserver_clientsonline',
            'virtualserver_name',
            'virtualserver_channelsonline',
            'virtualserver_queryclientsonline',
            'virtualserver_total_ping',
        ];
        $toReturn = [];
        $serverInfo = ServerInfo::all();

        foreach($serverInfo as $info) {
            if (in_array($info->key, $returnKeys)) {
                $toReturn[$info->key] = $info->value;
            }
        }

        return $toReturn;
    }

    /**
     * Return server info for ServerInfo page.
     *
     * @return array
     */
    public function all()
    {
        $toReturn = [];
        $serverInfo = ServerInfo::all();

        foreach($serverInfo as $info) {
            if ($info->key == 'virtualserver_uptime') {
                $toReturn[$info->key] = $this->helper->convertTime($info->value);
            } else {
                $toReturn[$info->key] = $info->value;
            }

        }

        return $toReturn;
    }
}
