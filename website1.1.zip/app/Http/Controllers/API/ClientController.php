<?php

namespace App\Http\Controllers\API;

use App\Client;
use App\Helpers\Helper;
use App\Http\Resources\ClientResource;
use App\ServerGroup;
use App\Http\Controllers\Controller;

class ClientController extends Controller
{
    protected $helper;

    /**
     * ClientController constructor.
     *
     * @param Helper $helper
     */
    public function __construct(Helper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Check if client has ignored group.
     *
     * @param $serverGroups
     *
     * @return bool
     */
    private function hasIgnoredGroup($serverGroups)
    {
        foreach (explode(',', $serverGroups) as $group)
            if ($group && $group != '' && in_array($group, config('config.top.ignoredGroups')))
                return true;

        return false;
    }

    /**
     * Return clients top by time spent.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function topTimeSpent()
    {
        $clients = Client::select('clientDbid', 'connectedTime', 'clientNick', 'connectedTimeSpent', 'lastOnline', 'serverGroups')->orderBy('connectedTimeSpent', 'desc')->get();
        $num = 1;

        foreach ($clients as $index => $client) {
            if ($this->hasIgnoredGroup($client->serverGroups)) {
                unset($clients[$index]);
                continue;
            }

            $clients[$index]->num = $num++;
            $clients[$index]->connectedTimeSpent = $this->helper->convertTime($client->connectedTimeSpent);
            $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }
        }


        return ClientResource::collection($clients);
    }

    /**
     * Return clients top by time record.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function topTimeRecord()
    {
        $clients = Client::select('clientDbid', 'connectedTime', 'clientNick', 'connectedTimeRecord', 'lastOnline', 'serverGroups')->orderBy('connectedTimeRecord', 'desc')->get();
        $num = 1;

        foreach ($clients as $index => $client) {
            if ($this->hasIgnoredGroup($client->serverGroups)) {
                unset($clients[$index]);
                continue;
            }

            $clients[$index]->num = $num++;
            $clients[$index]->connectedTimeRecord = $this->helper->convertTime($client->connectedTimeRecord);
            $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }
        }

        return ClientResource::collection($clients);
    }

    /**
     * Return clients top by idle time spent.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function topIdleTimeSpent()
    {
        $clients = Client::select('clientDbid', 'connectedTime', 'clientNick', 'idleTimeSpent', 'lastOnline', 'serverGroups')->orderBy('idleTimeSpent', 'desc')->get();
        $num = 1;

        foreach ($clients as $index => $client) {
            if ($this->hasIgnoredGroup($client->serverGroups)) {
                unset($clients[$index]);
                continue;
            }

            $clients[$index]->num = $num++;
            $clients[$index]->idleTimeSpent = $this->helper->convertTime($client->idleTimeSpent);
            $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }
        }

        return ClientResource::collection($clients);
    }

    /**
     * Return clients top by idle time record.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function topIdleTimeRecord()
    {
        $clients = Client::select('clientDbid', 'connectedTime', 'clientNick', 'idleTimeRecord', 'lastOnline', 'serverGroups')->orderBy('idleTimeRecord', 'desc')->get();
        $num = 1;

        foreach ($clients as $index => $client) {
            if ($this->hasIgnoredGroup($client->serverGroups)) {
                unset($clients[$index]);
                continue;
            }

            $clients[$index]->num = $num++;
            $clients[$index]->idleTimeRecord = $this->helper->convertTime($client->idleTimeRecord);
            $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }
        }

        return ClientResource::collection($clients);
    }

    /**
     * Return clients top by connections.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function topConnections()
    {
        $clients = Client::select('clientDbid', 'connectedTime', 'clientNick', 'connections', 'lastOnline', 'serverGroups')->orderBy('connections', 'desc')->get();
        $num = 1;

        foreach ($clients as $index => $client) {
            if ($this->hasIgnoredGroup($client->serverGroups)) {
                unset($clients[$index]);
                continue;
            }

            $clients[$index]->num = $num++;
            $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }
        }

        return ClientResource::collection($clients);
    }

    /**
     * Return online clients.
     *
     * @return \Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function online()
    {
        $clients = Client::select('clientDbid', 'clientNick', 'channelName')->where('lastOnline', '>', time() - config('config.main.onlineTime'))->get();

        return ClientResource::collection($clients);
    }

    /**
     * Return admins.
     *
     * @return array
     */
    public function admins()
    {
        $toReturn = [];

        foreach (config('config.main.adminGroups') as $adminGroup) {
            $clients = Client::query()
                ->select('clientDbid', 'clientNick', 'channelName', 'lastOnline', 'serverGroups', 'connectedTime')
                ->where('serverGroups', 'LIKE', '%,'.$adminGroup.',%')
                ->get();

            foreach ($clients as $index => $client) {
                $clients[$index]->statusBool = $this->helper->isOnline($client->lastOnline);
                if ($client->statusBool) {
                    $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
                } else {
                    $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
                }
            }

            $groupInfo = ServerGroup::where('sgid', $adminGroup)->first();
            if ($groupInfo) {
                $adminGroupInfo = ['sgid' => $adminGroup, 'name' => $groupInfo['name'], 'icon' => $groupInfo['icon']];
                $toReturn[$adminGroup] = ['adminGroup' => $adminGroupInfo, 'clients' => $clients];
            }
        }

        return $toReturn;
    }

    /**
     * Display the specified client.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $client = Client::where('clientDbid', $id)->first();

        if ($client) {
            $nicksHistory = [];

            $clientGroups = $client->serverGroups;
            $clientGroupsInfo = [];
            $client->serverGroups = [];
            foreach (explode(',', $clientGroups) as $group) {
                if ($group != '' && $group != ' ') {
                    $groupInfo = ServerGroup::where('sgid', $group)->first();
                    if ($groupInfo) {
                        $clientGroupsInfo[] = ['sgid' => $group, 'name' => $groupInfo['name'], 'icon' => $groupInfo['icon']];
                    }
                }
            }

            $num = 0;
            foreach ($this->topConnections() as $user) {
                $num++;
                if ($user->clientDbid == $id) {
                    $client->connectionsPlace = $num;
                    break;
                }
            }
            $num = 0;
            foreach ($this->topIdleTimeSpent() as $user) {
                $num++;
                if ($user->clientDbid == $id) {
                    $client->idleTimeSpentPlace = $num;
                    break;
                }
            }
            $num = 0;
            foreach ($this->topIdleTimeRecord() as $user) {
                $num++;
                if ($user->clientDbid == $id) {
                    $client->idleTimeRecordPlace = $num;
                    break;
                }
            }
            $num = 0;
            foreach ($this->topTimeRecord() as $user) {
                $num++;
                if ($user->clientDbid == $id) {
                    $client->connectedTimeRecordPlace = $num;
                    break;
                }
            }
            $num = 0;
            foreach ($this->topTimeSpent() as $user) {
                $num++;
                if ($user->clientDbid == $id) {
                    $client->connectedTimeSpentPlace = $num;
                    break;
                }
            }

            $client->connectedTimeRecord = $this->helper->convertTime($client->connectedTimeRecord);
            $client->connectedTimeSpent = $this->helper->convertTime($client->connectedTimeSpent);
            $client->idleTimeSpent = $this->helper->convertTime($client->idleTimeSpent);
            $client->idleTimeRecord = $this->helper->convertTime($client->idleTimeRecord);
            $client->weekTimeSpent = $this->helper->convertTime((int) $client->connectedTimeSpent - $client->weekStartTime);
            $client->serverGroups = $clientGroupsInfo;

            $client->statusBool = $this->helper->isOnline($client->lastOnline);
            if ($client->statusBool) {
                $client->lastOnline = date('d-m-Y H:i', time() - $client->connectedTime);
            } else {
                $client->lastOnline = date('d-m-Y H:i', $client->lastOnline);
            }

            $client->connectedTime = $this->helper->convertTime($client->connectedTime);

            foreach(json_decode($client->nicksHistory, 1) as $item) {
                $nicksHistory[] = ['nick' => $item['nick'], 'date' => date('d-m-Y H:i:s', $item['time'])];
            }

            $client->nicksHistory = json_encode($nicksHistory);

            return new ClientResource($client);
        } else {
            return ['data' => []];
        }
    }
}
