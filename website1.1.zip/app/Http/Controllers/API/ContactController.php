<?php

namespace App\Http\Controllers\API;

use App\Helpers\Helper;
use App\Http\Requests\ContactRequest;
use App\Mail\ContactFormMail;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    protected $helper;

    /**
     * ContactController constructor.
     *
     * @param Helper $helper
     */
    public function __construct(Helper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Sent contact email.
     *
     * @param ContactRequest $request
     *
     * @return array|\Illuminate\Http\JsonResponse
     */
    public function sent(ContactRequest $request)
    {
        if ($this->helper->checkContactRequests($request->ip())) {
            try {
                Mail::to(config('config.main.email'))
                    ->send(new ContactFormMail($request->input('nick'), $request->input('email'), $request->input('subject'), $request->input('message')));
            } catch (\Exception $e) {
                return response()->json([], 500);
            }

            $this->helper->setContactRequestTime($request->ip());
            return ['success' => true];
        } else {
            return response()->json([], 500);
        }
    }
}
