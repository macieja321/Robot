<?php

namespace App\Http\Controllers\API;

use App\Client;
use App\Http\Resources\ClientResource;
use App\Http\Controllers\Controller;

class SearchController extends Controller
{
    /**
     * Return clients by phrase.
     *
     * @param $phrase
     *
     * @return array|\Illuminate\Http\Resources\Json\AnonymousResourceCollection
     */
    public function search($phrase)
    {
        $result = Client::select('clientDbid', 'clientUid', 'clientNick')
            ->where('clientNick', 'like', '%'.$phrase.'%')
            ->orWhere('clientUid', 'like', '%'.$phrase.'%')
            ->orWhere('clientDbid', 'like', '%'.$phrase.'%')
            ->get();

        if ($result) {
            return ClientResource::collection($result);
        } else {
            return ['data' => []];
        }
    }
}
