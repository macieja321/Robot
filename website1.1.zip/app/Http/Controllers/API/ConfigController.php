<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Lang;

class ConfigController extends Controller
{
    /**
     * Return faq array from config.
     *
     * @return \Illuminate\Config\Repository|mixed
     */
    public function faq()
    {
        return config('config.faq');
    }

    /**
     * Return regulations html from config.
     *
     * @return \Illuminate\Config\Repository|mixed
     */
    public function regulations()
    {
        return config('config.regulations');
    }
}
