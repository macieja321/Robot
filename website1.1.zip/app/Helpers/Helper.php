<?php
/**
 * @author     Tymoteusz `RazorMeister` Bartnik
 * @file       TimeHelper
 */

namespace App\Helpers;

use App\Client;
use Illuminate\Support\Facades\Cache;

class Helper
{
    /**
     * Convert time.
     *
     * @param $seconds
     * @param array $settings
     *
     * @return string
     */
    public function convertTime($seconds, $settings = ['days' => true, 'hours' => true, 'minutes' => true])
    {
        $toReturn = '';
        $seconds = round($seconds);

        if (isset($settings['days']) && $settings['days']) {
            $time['d'] = floor($seconds / 86400);
            $seconds -= $time['d']*86400;
            if ($time['d'] > 0) $toReturn .= $this->tipOfWords($time['d'], 'days');
        }
        if (isset($settings['hours']) && $settings['hours']) {
            $time['h'] = floor($seconds / 3600);
            $seconds -= $time['h']*3600;
            if ($time['h'] > 0) $toReturn .= $this->tipOfWords($time['h'], 'hours');
        }
        if (isset($settings['minutes']) && $settings['minutes']) {
            $time['m'] = floor($seconds / 60);
            $seconds -= $time['m']*3600;
            if ($time['m'] > 0) $toReturn .= $this->tipOfWords($time['m'], 'minutes');
        }

        return ($toReturn != '' ? $toReturn : $this->tipOfWords($seconds, 'seconds'));
    }

    /**
     * Translate words' tips like second/s etc.
     *
     * @param $count
     * @param $type
     *
     * @return string
     */
    public function tipOfWords($count, $type)
    {
        $tip = '';

        switch ($type) {
            case 'days':
                if ($count == 1) $tip = trans('lang.day');
                else $tip = trans('lang.days');
                break;
            case 'hours':
                if ($count == 1) $tip = trans('lang.hour');
                else if ($count > 1 && $count < 5) $tip = trans('lang.hours');
                else $tip = trans('lang.hours2');
                break;
            case 'minutes':
                if ($count == 1) $tip = trans('lang.minute');
                else if ($count > 1 && $count < 5) $tip = trans('lang.minutes');
                else $tip = trans('lang.minutes2');
                break;
            case 'seconds':
                if ($count == 1) $tip = trans('lang.second');
                else if ($count > 1 && $count < 5) $tip = trans('lang.seconds');
                else $tip = trans('lang.seconds2');
        }

        return $count.' '.$tip.' ';
    }

    /**
     * Check if client is online.
     *
     * @param int $lastOnline
     *
     * @return bool
     */
    public function isOnline(int $lastOnline)
    {
        if (time() - $lastOnline > config('config.main.onlineTime')) {
            return false;
        } else {
            return true;
        }
    }

    private function getCounterInfo()
    {
        return [
            'clients'       => Client::count(),
            'hours'         => round(Client::sum('connectedTimeSpent')/3600),
            'connections'   => Client::sum('connections'),
        ];
    }

    /**
     * Return array with cfg to vue app.
     *
     * @return array
     */
    public function getVueCfg()
    {
        $subfolder = config('config.main.subfolder');

        if ($subfolder != "") {
            if ($subfolder[0] == "/")
                $subfolder = substr($subfolder, 1);
            if ($subfolder[strlen($subfolder) - 1] != '/')
                $subfolder .= '/';
        }

        return [
            'siteName'          => config('config.main.siteName'),
            'titlePrefix'       => config('config.main.titlePrefix'),
            'socketIo'          => ['host' => config('config.socketIo.host'), 'ssl' => env('SSL')],
            'home'              => config('config.home'),
            'ts3link'           => config('config.main.ts3link'),
            'counterInfo'       => $this->getCounterInfo(),
            'subfolder'         => $subfolder,
            'darkTheme'         => config('config.main.darkTheme'),
        ];
    }

    public function checkContactRequests($ip)
    {
        if ($cache = Cache::get('email'.$ip)){
            return false;
        } else {
            return true;
        }
    }

    public function setContactRequestTime($ip)
    {
        Cache::put('email'.$ip, 1, config('config.contact.interval'));
    }
}
