<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ContactFormMail extends Mailable
{
    use Queueable, SerializesModels;

    public $nick, $email, $subject, $message;

    /**
     * Create a new message instance.
     *
     * @param string $nick
     * @param string $email
     * @param string $subject
     * @param string $message
     */
    public function __construct(string $nick, string $email, string $subject, string $message)
    {
        $this->nick = $nick;
        $this->email = $email;
        $this->subject = $subject;
        $this->message = $message;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from($this->email, $this->nick)->markdown('contact.email');
    }
}
