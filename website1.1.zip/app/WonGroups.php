<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WonGroups extends Model
{
    /**
     * Custom table name.
     */
    protected $table = 'won_groups';
}
