<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServerInfo extends Model
{
    /**
     * Custom table name.
     */
    protected $table = 'server_info';
}
