const dotenv = require('dotenv').config({path: '../.env'});
const fs = require('fs');
let isCloudflare;
let isSsl = false;
let hostName = process.env.APP_URL;

if (hostName[hostName.length-1] == "/")
    hostName = hostName.substring(0, hostName.length-1);

if (process.env.SSL == '1' || process.env.SSL == 'true') {
	const https = require('https');
	const app = require('express')();

	if (process.env.CLOUDFLARE_SSL == '1' || process.env.CLOUDFLARE_SSL == 'true')
		isCloudflare = true;
	else
		isCloudflare = false;

	const options = {
	  key: fs.readFileSync('ssl/server.key'),
	  cert: fs.readFileSync('ssl/final.crt'),
	};

	var server = https.createServer({
		key: fs.readFileSync('ssl/server.key'),
		cert: fs.readFileSync('ssl/final.crt'),
		requestCert: false,
		rejectUnauthorized: false
	},app);
	server.listen(2053);
	isSsl = true;

} else {
	isCloudflare = false;

	const http = require('http');

	var server = http.createServer(function (req, res) {
      res.writeHead(200);
	});

	server.listen(2053);
}

const io = require('socket.io').listen(server);

const { TeamSpeak } = require("ts3-nodejs-library");
const axios = require('axios');

const mysql = require('mysql');

let trans = {};
let clientTokens = {};
const SLOWER = true;
const tokenTime = 60;

log(strReplace("> [DATE] - Downloading data from website", ['[DATE]'], [getCurrentDate()]));

axios.get(hostName + '/api/botLang')
	.then(async response => {
		trans = response.data;

        log(strReplace(trans.connected.downloadLang, ['[DATE]'], [getCurrentDate()]));

        if (isSsl)
            log(strReplace(trans.connected.https, ['[DATE]'], [getCurrentDate()]));
        else
            log(strReplace(trans.connected.http, ['[DATE]'], [getCurrentDate()]));

        log(strReplace(trans.connected.ts3init, ['[DATE]'], [getCurrentDate()]));

        TeamSpeak.connect({
            host: process.env.TS3_HOST,
            queryport: process.env.TS3_QUERY_PORT,
            serverport: process.env.TS3_SERVER_PORT,
            username: process.env.TS3_USERNAME,
            password: process.env.TS3_PASSWORD,
            nickname: process.env.TS3_NICKNAME,
            readyTimeout: 2000,
        }).then(teamspeak => {
            log(strReplace(trans.connected.ts3, ['[DATE]'], [getCurrentDate()]));
			clearTokens(teamspeak);
			refreshTS(teamspeak);

			teamspeak.whoami().then(async me => {
				await teamspeak.clientMove(me.client_id, process.env.TS3_DEFAULT_CHANNEL);
			});

			io.on('connection', socket => {
				socket.on('addGroup', async data => {
					auth(socket, data.token, teamspeak).then(client => {
						let toReturn = {};
						let err = false;
						let ipV4 = getIpV4(socket);
						let dbid = data.dbid;

						if (client.hasOwnProperty('namespace')) {
							axios.get(hostName + '/api/groups/' + data.dbid) // checking auth
								.then(async response => {
									let toAdd = [], toDel = [];
									data = data.data;

									for (const section in response.data) {
										let info = response.data[section];
										let limit = info.limit;
										let sectionGroups = info.groups;

										if (data[section] && data[section].length > limit) { // checking limit
										toReturn['msg'] = strReplace(trans.addGroup.limitErr, ['[SECTION]', '[LIMIT]'], [section, limit]);
											err = true;
											break;
										} else { // checking if groups are in cfg
											let isIn;

											for (const num in data[section]) {
												isIn = false;

												for (const index in sectionGroups) {
													if (sectionGroups[index].sgid == data[section][num].sgid) {
														isIn = true;
														break;
													}
												}

												toAdd.push(data[section][num].sgid);

												if (!isIn) {
													toReturn['msg'] = strReplace(trans.addGroup.wrongGroup, '[SGID]', data[section][num].sgid);
													err = true;
													break;
												}
											}

											for (const index in sectionGroups)
												if (!toAdd.includes(sectionGroups[index].sgid) && client.servergroups.includes(sectionGroups[index].sgid))
													toDel.push(sectionGroups[index].sgid);

											if (err)
												break;
										}
									}

									if (err) {
										client.message(trans.addGroup.clientMsgError);
										toReturn['success'] = false;
										toReturn['code'] = 1;
										log(strReplace(trans.addGroup.logInfoError, ['[DATE]', '[INFO]', '[DBID]', '[IP]'], [getCurrentDate(), toReturn['msg'], dbid, ipV4]));
									} else {
										toReturn['success'] = true;
										log(strReplace(trans.addGroup.logInfoSuccess, ['[DATE]', '[INFO]', '[DBID]', '[IP]'], [getCurrentDate(), '', dbid, ipV4]));

										toDel.forEach(del => {
											client.delGroups(del);
										});

										toAdd.forEach(add => {
											if (!client.servergroups.includes(add))
												client.addGroups(add);
										});

										let clientInfo = await client.getInfo();
										let serverGroupsString = ',' + clientInfo.client_servergroups.join() + ',';

										var con = mysql.createConnection({
										  host: process.env.DB_HOST,
										  user: process.env.DB_USERNAME,
										  password: process.env.DB_PASSWORD,
										  database: process.env.DB_DATABASE,
										  port: process.env.DB_PORT,
										});

										con.connect(async function(err) {
											if (err) {
													log(err);
													process.exit();
												}
											var sql = "UPDATE clients SET serverGroups = '" + serverGroupsString + "' WHERE clientDbid = " + dbid;
											await con.query(sql, function (err, result) {
												if (err) {
													log(err);
													process.exit();
												}
												log(result.affectedRows + " record(s) updated");
												con.end();
											});
										});

										client.message(trans.addGroup.clientMsgSuccess);
									}

									socket.emit('responseGroup', toReturn);
								})
								.catch(error => {
									log(error);
									toReturn['success'] = false;
									toReturn['msg'] = trans.addGroup.cannotAccessServer;
									toReturn['code'] = 2;
									log(strReplace(trans.addGroup.logInfoError, ['[DATE]', '[INFO]', '[DBID]', '[IP]'], [getCurrentDate(), toReturn['msg'], dbid, ipV4]));
									client.message(trans.addGroup.clientMsgError);
									socket.emit('responseGroup', toReturn);
								});
						} else {
							toReturn['success'] = false;
							toReturn['msg'] = trans.addGroup.authError;
							toReturn['code'] = 3;
							log(strReplace(trans.addGroup.logInfoError, ['[DATE]', '[INFO]', '[DBID]', '[IP]'], [getCurrentDate(), toReturn['msg'], dbid, ipV4]));
							socket.emit('responseGroup', toReturn);

						}
					});
				});


				socket.on('getClients', async data => {
					let ipV4 = getIpV4(socket);
					let toReturn = [];
					let toLog = [];

					if (SLOWER) await sleep(1000);

					const clients = await teamspeak.clientList({ client_type: 0 })
					clients.forEach(client => {
						if (client.connectionClientIp === ipV4) {
							toReturn.push({nickname: client.nickname, dbid: client.databaseId});
							toLog.push(' ' + client.nickname + '[' + client.databaseId + ']');
						}
					})

					log(strReplace(trans.getClients.logInfo, ['[DATE]', '[CLIENTS]', '[IP]'], [getCurrentDate(), toLog.join(), ipV4]));

					socket.emit('returnClients', toReturn);
				});

				socket.on('sendToken', async dbid => {
					let ipV4 = getIpV4(socket);
					let found = false;

					if (SLOWER) await sleep(1000);

					if (clientTokens[dbid] && Date.now() - clientTokens[dbid].time < 60 * 1000) {
						const clients = await teamspeak.clientList({ client_type: 0 })
						clients.forEach(client => {
							if (client.connectionClientIp === ipV4 && client.databaseId == dbid)
								found = true;
						})

						if (found)
							log(strReplace(trans.sendToken.logInfoAlreadySent, ['[DATE]', '[TOKEN]', '[DBID]', '[IP]'], [getCurrentDate(), clientTokens[dbid].token, dbid, ipV4]));

					} else {
						let token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

						const clients = await teamspeak.clientList({ client_type: 0 })
						clients.forEach(client => {
							if (client.connectionClientIp === ipV4 && client.databaseId == dbid) {
								client.message(strReplace(trans.sendToken.clientMsg, ['[TOKEN]', '[TIME]'], [token, tokenTime]));
								clientTokens[dbid] = {time: Date.now(), token: token, loged: false};
								found = true;
							}
						})

						if (found)
							log(strReplace(trans.sendToken.logInfoSuccess, ['[DATE]', '[TOKEN]', '[DBID]', '[IP]'], [getCurrentDate(), token, dbid, ipV4]));
					}

					if (!found)
						if (found)
							log(strReplace(trans.sendToken.logInfoRrror, ['[DATE]', '[TOKEN]', '[DBID]', '[IP]'], [getCurrentDate(), token, dbid, ipV4]));

					socket.emit('sendTokenConfirmation', found);
				});

				socket.on('checkToken', async data => {
					let ipV4 = getIpV4(socket);
					let isValid = false;

					if (SLOWER) await sleep(1000);

					const clients = await teamspeak.clientList({ client_type: 0 })
					clients.forEach(client => {
						if (client.connectionClientIp === ipV4 && client.databaseId == data.dbid) {
							if (clientTokens[data.dbid].token == data.token) {
								client.message(trans.checkToken.clientMsgSuccess);
								clientTokens[data.dbid].loged = true;
								isValid = true;
							} else
								client.message(trans.checkToken.clientMsgError);
						}
					})

					if (isValid)
						log(strReplace(trans.checkToken.logInfoSuccess, ['[DATE]', '[TOKEN]', '[DBID]', '[IP]'], [getCurrentDate(), data.token, data.dbid, ipV4]));
					else
						log(strReplace(trans.checkToken.logInfoError, ['[DATE]', '[TOKEN]', '[DBID]', '[IP]'], [getCurrentDate(), data.token, data.dbid, ipV4]));

					socket.emit('checkTokenResponse', isValid);
				});

				socket.on('checkOnServer', async data => {
					let ipV4 = getIpV4(socket);
					let found = false;

					if (clientTokens[data.dbid] && clientTokens[data.dbid].token == data.token && clientTokens[data.dbid].loged) {
						if (SLOWER) await sleep(1000);

						const clients = await teamspeak.clientList({ client_type: 0 })
						clients.forEach(client => {
							if (client.connectionClientIp === ipV4 && client.databaseId == data.dbid)
								found = true;
						})
					}

					if (!found) {
						delete clientTokens[data.dbid];
						socket.emit('checkOnServerResponse', {onServer: false});
					};
				});

				socket.on('logout', async data => {
					let ipV4 = getIpV4(socket);
					if (SLOWER) await sleep(1000);

					auth(socket, data.token, teamspeak).then(client => {
						if (client.hasOwnProperty('namespace')) {
							client.message(trans.logout.clientMsg);
							log(strReplace(trans.logout.logInfo, ['[DATE]', '[DBID]', '[IP]'], [getCurrentDate(), client.databaseId, ipV4]))
							delete clientTokens[client.databaseId];
						}
					});
				});
			});
		}).catch(e => {
            log(trans.ts3Error);
            console.error(e);
            process.exit();
        })

	})
	.catch(e => {
		log('> Getting language file error');
		log(e);
		process.exit();
	});

function log(text) {
	let fullLog = '';
	try {
		fullLog = fs.readFileSync('logs.txt') + '\n' + text;
	} catch (e) {
	}

	fs.writeFile("logs.txt", fullLog, function(err) {
		if(err)
			return console.log(err);
	});
	console.log(text);
}

function getCurrentDate() {
	return new Date().toLocaleString();
}

function strReplace(string, what, to) {
	if (Array.isArray(what)) {
		for (let key in what)
			string = string.replace(what[key], to[key]);
	} else
		string = string.replace(what, to);

	return string;
}

async function refreshTS(teamspeak) {
	const clients = teamspeak.clientList({ client_type: 0 })
	setTimeout(function () { refreshTS(teamspeak) }, 60000);
}

async function clearTokens(teamspeak) {
	const clients = await teamspeak.clientList({ client_type: 0 })

	for (let dbid in clientTokens) {
		if (!clientTokens[dbid].loged && Date.now() - clientTokens[dbid].time > tokenTime * 1000) {
			delete clientTokens[dbid];
		} else {
			let found = false;

			clients.forEach(client => {
				if (client.databaseId == dbid) {
					found = true;
				}
			})

			if (!found)
				delete clientTokens[dbid];
		}
	}

	setTimeout(function () { clearTokens(teamspeak) }, 5000);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getIpV4(ip) {
	if (isCloudflare) {
		return ip.handshake.headers['x-forwarded-for'];
	} else {
		ip = ip.request.connection._peername;
		if (ip.family == 'IPv6')
			return ip.address.slice(ip.address.lastIndexOf(':') + 1, ip.address.length);
		else
			return ip.address;
	}
}

async function auth(ip, requestToken, teamspeak) {
	let ipV4 = getIpV4(ip);
	let toReturn = {};

	const clients = await teamspeak.clientList({ client_type: 0 })

	clients.forEach(client => {
		if (client.connectionClientIp === ipV4 && clientTokens[client.databaseId] && clientTokens[client.databaseId].token == requestToken && clientTokens[client.databaseId].loged) {
			toReturn = client;
		}
	})

	return toReturn;
}
