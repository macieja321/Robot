<?php

return [
    'main' => [
        'titlePrefix'       => '» ',
        'siteName'          => 'RO-BOT Website',
        'siteDescription'   => 'Strona pod serwery głosowe TS3',
        'keywords'          => 'ts3,strona,panel,teamspeak',
        'email'             => 'battnik90@gmail.com',
        'ts3link'           => 'ro-bot.pl',
        'onlineTime'        => 150,
        'adminGroups'       => [120,121,129,135],
        'themeColor'        => '#FF9000',
        'subfolder'         => '',	// Important if your website is: http://bestspeak.pl/website/, then type here 'website/'
        'darkTheme'         => true,
    ],
    'socketIo' => [
        'host'  => 'https://website.ro-bot.net:2053',
    ],
    'facebook'  => [
        'link'  => "https://www.facebook.com/robotpl",
        'name'  => 'RO-BOT.pl',
    ],
    'home' => [
        'parallax' => [
            'imageText'     => 'Co nas wyróżnia?',
            'words'         => ['Profesjonalizm', 'Bezpieczeństwo', 'Doświadczenie'],
        ],
        'infoSection' => [
            'header'    => 'Profesjonalny serwer TeamSpeak3 dla CIEBIE!',
            'desc'      => 'Istniejemy już od kilku lat, co oznacza, że posiadamy duże doświadczenie w branży serwerów głosowych TeamSpeak3.',
        ],
    ],
    'footer' => [
        'info'  => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempus elit ac est gravida dignissim. Mauris lobortis enim ac tortor",
    ],
    'manageGroups' => [
        'wiekowe' => [
            'limit'     => 1,
            'groups'    => [69,70,71,72,73,74,75],
         ],
        'wojedództwo' => [
            'limit'     => 2,
            'groups'    => [51,52,53,54,55,56,57],
        ],
        '4fun' => [
            'limit'     => 4,
            'groups'    => [37,38,39,40,41,42,43],
        ],
    ],
    'contact' => [
        'interval' => 60, // in seconds
    ],
    'top' => [
        'ignoredGroups' => [120,142,27],
    ],
    'faq' => [
        '<i class="fa fa-server"></i> Serwer' => [
            '1. Dlaczego nie widzę osób na kanałach?' => 'Masz wyłączoną opcję Subscribe to all channels w Opcjach (Application) lub nie posiadasz odpowiedniej grupy na serwerze.',
            '2. Jak dodać kogoś do znajomych?' => 'Klikamy PPM na użytkowniku, którego chcemy dodać, a następnie zaznaczamy opcję Add as Friend.',
            '3. Jak mogę wstawić sobie avatar?' => 'Klikamy PPM na siebie i zaznaczamy opcję Set Avatar.',
        ],
        '<i class="fa fa-users"></i> Użytkownicy' => [
            '1. Dlaczego nie słysze innych osób?' => 'Na górze TeamSpeak 3 wejdź w narzędzia, następnie kliknij opcje. Potem znajdź odtwarzanie, w nim urządzenie odtwarzania i wybierz np. Głośnik lub Słuchawki.',
            '2. Dlaczego inni mnie nie słyszą?' => 'Na górze TeamSpeak 3 wejdź w narzędzia, następnie kliknij opcje. Potem znajdź przechwytywanie, w nim tryb przechwytywania i wybierz np. Mikrofon Wbudowany.',
            '3. Jak usunąć echo?' => 'Na górze TeamSpeak 3 wejdź w narzędzia, następnie kliknij opcje. Potem znajdź przechwytywanie, w nim zaznacz opcje naciśnij i mów, następnie zaznacz opcje redukcji i usuwania echa, potem opcje zaawansowane i zaznacz Usuń szumy w tle.',
        ],
    ],
    'regulations' => '<p>
<strong><span class="text-accent">§ INFORMACJE</span></strong>
<br/>
<span class="text-accent">§1.</span> Użytkownicy nie podważają zdania administracji.<br/>
<span class="text-accent">§2.</span> Przebywając na naszym serwerze zgadzasz się na wszystkie warunki regulaminu.<br/>
<span class="text-accent">§3.</span> Użytkownik ma zakaz wchodzenia na kanał prywatny innego użytkownika bez jego zgody.<br/>
<span class="text-accent">§4.</span> Zabrania się "skakania" po kanałach.<br/>
<span class="text-accent">§5.</span> Zabrania się używania obraźliwych, wulgarnych, rasistowskich nicków i nazw kanałów.<br/>
<span class="text-accent">§6.</span> Nie wolno obrażać w jakikolwiek sposób innych użytkowników.<br/>
<span class="text-accent">§7.</span> Zabrania się prowokowania do kłótni.<br/>
<span class="text-accent">§8.</span> Nagrywanie rozmów i puszczanie muzyki na kanałach publicznych, oraz na kanałach prywatnych bez zgody właściciela kanału są zakazane. <br/>
<span class="text-accent">§10.</span> Zabronione jest spamowanie na serwerze.<br/>
<span class="text-accent">§11.</span> Użytkownik ma prawo posiadać maksymalnie 5 ikonek/rang nie licząc channel admina, rang wiekowych oraz weryfikacyjnych typu zarejstrowany zarejstrowana.<br/>
<br/>
<strong><span class="text-accent">§ ZASADY OGÓLNE</span></strong>
<br/>
<span class="text-accent">§1.</span> Zabronione jest używanie nazw:<br/>
a) Wulgarnych, obraźliwych, rasistowskich, nazistowskich, nieetycznych;<br/>
b) Zawierających ciąg tych samych znaków bądź krótszych niż 3 znaki;<br/>
c) TeamSpeakUser (domyślnej nazwy);<br/>
d) Podszywających się pod osoby z wyższej administracji serwera Team Speak 3<br/>
<span class="text-accent">§2.</span> Zabronione jest używania awatarów zawierających treści erotyczne, wulgarne, rasistowskie, nazistowskie, nieetyczne bądź obraźliwe.<br/>
<span class="text-accent">§3.</span> Zabronione jest reklamowanie innych serwerów głosowych, serwerów gier, stron internetowych, for, itd.
<span class="text-accent">§4.</span> Zabronione jest nagminne zmienianie nazw użytkownika.<br/>
<span class="text-accent">§5.</span> Zabronione jest podszywanie się pod kogoś, posiadanie takiej samej nazwy użytkownika w celu żartu.<br/>
<span class="text-accent">§6.</span> Zabronione jest wysyłanie w wiadomościach linków przekierowujących na niebezpieczne strony lub aplikacje.<br/>
<span class="text-accent">§7.</span> Zabronione jest używanie czatu ogólnego. Nie tyczy się właściciela serwera.<br/>
<span class="text-accent">§8.</span> Zabronione jest spamowanie poke`ami bądź whisper`ami.<br/>
<span class="text-accent">§9.</span> Na serwerze staramy się pisać zgodnie z zasadami zachowania poprawnej polszczyzny, w sposób zrozumiały dla osób przebywających na serwerze.<br/>
<span class="text-accent">§10.</span> Zabronione jest podszywanie się pod admina.<br/>
<span class="text-accent">§11.</span> Zabronione jest ustawianie sobie dziwnych prefiksów bądź przedrostków, które są używane przy danej grupie rang.<br/>
<span class="text-accent">§12.</span> Zabranione jest używanie VPN lub Proxy aby połączyć się z serwerem<br/>
<span class="text-accent">§13.</span> Zabronione jest używanie modulatora przez użytkowników<br/>
<span class="text-accent">§14.</span> Właściciel ma prawo do zbanowania osoby bez powodu.<br/>
<span class="text-accent">§15.</span> Zdanie własciciela jest niepodważalne.<br/>
<span class="text-accent">§16.</span> Administrator może być tylko w administracji na jednym serwerze teamspeak<br/>
<br/>
<strong><span class="text-accent">§ KANAŁY GLOBALNE</span></strong>
<br/>
<span class="text-accent">§1.</span> Zakaz nagrywania rozmów na kanałach globalnych bez zgody osób, które na nim przesiadują. Nie tyczy się to kanałów, które posiadają zgodę na nagrywanie w opisie.<br/>
<span class="text-accent">§2.</span> Zakazane jeszcze puszczanie muzyki bez zgody osób przebywających na kanale.<br/>
<span class="text-accent">§3.</span> Kanały globalne są podzielone na te z limitem osób oraz na takie, które tego limitu nie posiadają.<br/>
<span class="text-accent">§4.</span> Łamanie zasad regulamin na kanałach globalnych skutkuje interwencją admina i wyrzuceniem danej osoby z kanału.<br/>
<span class="text-accent">§5.</span> Kanały globalne są prze<br/>znaczone dla osób korzystających z serwera TeamSpeak3. Głównie dla osób nie posiadających własnych kanałów.<br/>
<br/>
<strong><span class="text-accent">§ KANAŁY PRYWATNE</span></strong>
<br/>
<span class="text-accent">§1.</span> Kanały prywatne mogą posiadać maksymalnie trzy podkanały.<br/>
<span class="text-accent">§2.</span> Każdy użytkownik może posiadać maksymalnie jeden kanał prywatny.<br/>
<span class="text-accent">§3.</span> Zakazane jest zmienianie opisu (deskrypcji) kanału. Zmiana ta grozi usunięciem kanału.<br/>
<span class="text-accent">§4.</span> Brak numeru kanału lub zmiana go, grozi usunięciem kanału.<br/>
<span class="text-accent">§5.</span> Nazwa kanału nie może zawierać wulgaryzmów, treści rasistowskich, obraźliwych. Grozi to usunięciem kanału i zbanowaniem jego właściciela.<br/>
<span class="text-accent">§6.</span> Osoba korzystająca z kanałów prywatnych jest zobowiązana do przestrzegania regulaminu serwera TeamSpeak3.<br/>
<span class="text-accent">§7.</span> Za atmosferę na kanale odpowiada jego właściciel, a nie admin serwera TeamSpeak3.<br/>
<span class="text-accent">§8.</span> Każdy kanał nie posiadający hasła, staje się kanałem publicznym do którego może wejść każdy.<br/>
</p>
<div class="float-right"><i>Copyright by ro-bot.pl</i></div>',
];
