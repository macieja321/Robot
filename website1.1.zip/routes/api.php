<?php

use Illuminate\Http\Request;
use App\Client;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('clients/top/timeSpent', 'API\ClientController@topTimeSpent');
Route::get('clients/top/timeRecord', 'API\ClientController@topTimeRecord');
Route::get('clients/top/connections', 'API\ClientController@topConnections');
Route::get('clients/top/idleTimeSpent', 'API\ClientController@topIdleTimeSpent');
Route::get('clients/top/idleTimeRecord', 'API\ClientController@topIdleTimeRecord');
Route::get('clients/online', 'API\ClientController@online');
Route::get('clients/admins', 'API\ClientController@admins');
Route::get('client/{client}', 'API\ClientController@show');

Route::get('config/regulations', 'API\ConfigController@regulations');
Route::get('config/faq', 'API\ConfigController@faq');

Route::get('serverInfo/all', 'API\ServerInfoController@all');
Route::get('serverInfo/home', 'API\ServerInfoController@home');

Route::post('contact', 'API\ContactController@sent');

Route::get('search/{phrase}', 'API\SearchController@search');

Route::get('groups/{dbid}', 'API\GroupsController@index');

Route::get('botLang', 'API\BotLangController@index');